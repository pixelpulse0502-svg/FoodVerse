export { prerender, version } from "./static";
