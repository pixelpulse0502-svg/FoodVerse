`react-router` is the primary package in the React Router project.

## Installation

```sh
npm i react-router
```
