// THIS FILE IS AUTO GENERATED
module.exports = require('./lib/index.js');